from configparser import ConfigParser
import email
from multiprocessing import Manager
from pyexpat import model
from statistics import mode
from tracemalloc import DomainFilter
from django.db import models
from pkg_resources import WorkingSet
from django import forms
from django.contrib.auth.models import AbstractUser


class UserEmployee(AbstractUser):

    POSITION_CHOICES = [
    (1, 'Fresher'),
    (2, 'Experience'),
    ]

    APPLY_CHOICES = [
    (1, 'Agent'),
    (2, 'Social_media'),
    ]

    is_manager = models.BooleanField(default=False)
    is_agent = models.BooleanField(default=False)
    #name = models.CharField(max_length=24)
    mobile_number = models.CharField(max_length=10)
    birth_date = models.DateField(null=True, blank=True)  
    #linkein_link = models.CharField(max_length=24, blank=True)
    #github_link = models.CharField(max_length=24, blank=True)
    #website_link = models.CharField(max_length=24, blank=True)
    per_10th = models.FloatField(null=True, verbose_name='10th %')
    per_12th = models.FloatField(null=True, verbose_name='12th %')
    stream = models.CharField(max_length=24)
    fresher_expiriance = models.CharField(max_length=24, choices=POSITION_CHOICES)
    agent_socialmedia = models.CharField(max_length=24, choices=APPLY_CHOICES)
    status = models.CharField(max_length=24, default='In Progress')
    
    def __str__(self):
        return f"{self.username}: {self.first_name}: {self.last_name}: {self.mobile_number}: {self.email}: {self.per_10th}: {self.per_12th}: {self.per_12th}: {self.stream}: {self.fresher_expiriance}: {self.agent_socialmedia}: {self.status}"


class Education(models.Model):

    name = models.ForeignKey(UserEmployee, on_delete=models.CASCADE, related_name="education")
    degree_name = models.CharField(max_length=24)
    collage_name = models.CharField(max_length=24)
    cgpa = models.FloatField(null=True)

    def __str__(self):
        return f"{self.degree_name}: {self.collage_name}: {self.cgpa}: {self.name}"


class Experience(models.Model):

    name = models.ForeignKey(UserEmployee, on_delete=models.CASCADE, related_name="experiance")
    company_name = models.CharField(max_length=24)
    year_of_experience = models.IntegerField() 
    work = models.TextField()
    domain = models.CharField(max_length=24)
    salary = models.FloatField(null=True)
    def __str__(self):
        return f"{self.company_name}: {self.year_of_experience}: {self.work}: {self.domain}: {self.salary}: {self.name}"

  
class AgentManager(models.Model):

    POST_CHOICES = [
    (1, 'Manager'),
    (2, 'Agent'),
    ]

    username = models.OneToOneField(UserEmployee, on_delete = models.CASCADE)
    post = models.CharField(max_length=24, choices=POST_CHOICES)
    name = models.CharField(max_length=24)
    code = models.CharField(max_length=24)
    mobile_number = models.IntegerField()

    def __str__(self):
        return f"{self.name}: {self.code}: {self.mobile_number}: {self.name}: {self.username}"
