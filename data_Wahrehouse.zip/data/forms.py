
from django import forms
from data.models import UserEmployee, Education, Experience, AgentManager
from django.contrib.auth.forms import UserCreationForm, UserChangeForm


class LoginForm(forms.ModelForm):

    class Meta:
        model = UserEmployee
        fields = ('username', 'password')


class UserEmployeeForm(UserCreationForm):

    class Meta:
        model = UserEmployee
        fields = ['username','first_name','last_name', 'birth_date', 'mobile_number', 'email', 'per_10th','per_12th', 'stream', 'fresher_expiriance', 'agent_socialmedia', 'status']


class EducationForm(forms.ModelForm):

    class Meta:
        model = Education
        fields = ['name','degree_name','collage_name', 'cgpa', 'name']


class ExperienceForm(forms.ModelForm):

    class Meta:
        model = Experience
        fields = ['name', 'company_name', 'year_of_experience', 'work', 'domain', 'salary', 'name']


class AgentManagerForm(forms.ModelForm):

    class Meta:
        model = AgentManager
        fields = ['username', 'name', 'code', 'mobile_number', 'post']
